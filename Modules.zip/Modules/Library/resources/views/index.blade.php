<x-library::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('library.name') !!}</p>
</x-library::layouts.master>
