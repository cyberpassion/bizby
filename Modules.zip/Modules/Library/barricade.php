<?php
return [
    'path.library.create' => [],
	'path.library.read' => [],
	'path.library.update' => [],
	'path.library.delete' => [],
	'path.library.list' => [],
	'path.library.document' => [],
];