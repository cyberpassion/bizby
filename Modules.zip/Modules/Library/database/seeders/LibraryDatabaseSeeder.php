<?php

namespace Modules\Library\Database\Seeders;

use Illuminate\Database\Seeder;

class LibraryDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
