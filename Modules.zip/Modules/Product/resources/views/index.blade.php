<x-product::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('product.name') !!}</p>
</x-product::layouts.master>
