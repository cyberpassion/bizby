<?php

return [
    'name' => 'Visitplanner',
];
