<x-saleservice::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('saleservice.name') !!}</p>
</x-saleservice::layouts.master>
