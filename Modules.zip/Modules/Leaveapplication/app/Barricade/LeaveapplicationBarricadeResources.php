<?php

namespace Modules\Leaveapplication\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class LeaveapplicationBarricadeResources
{
    public static function register(): void
    {
        
    }
}
