<?php
return [
    'path.leaveapplication.create' => [],
	'path.leaveapplication.read' => [],
	'path.leaveapplication.update' => [],
	'path.leaveapplication.delete' => [],
	'path.leaveapplication.list' => [],
	'path.leaveapplication.document' => [],
];