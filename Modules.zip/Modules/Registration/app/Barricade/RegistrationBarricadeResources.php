<?php

namespace Modules\Registration\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class RegistrationBarricadeResources
{
    public static function register(): void
    {
        
    }
}
