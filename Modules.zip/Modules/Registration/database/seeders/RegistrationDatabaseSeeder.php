<?php

namespace Modules\Registration\Database\Seeders;

use Illuminate\Database\Seeder;

class RegistrationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
