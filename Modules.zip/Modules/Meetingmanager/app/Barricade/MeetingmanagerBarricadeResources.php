<?php

namespace Modules\Meetingmanager\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class MeetingmanagerBarricadeResources
{
    public static function register(): void
    {
        
    }
}
