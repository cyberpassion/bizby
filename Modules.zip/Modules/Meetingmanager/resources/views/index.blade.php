<x-meetingmanager::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('meetingmanager.name') !!}</p>
</x-meetingmanager::layouts.master>
