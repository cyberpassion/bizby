<?php

namespace Modules\Meetingmanager\Database\Seeders;

use Illuminate\Database\Seeder;

class MeetingmanagerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
