<?php

return [
    'name' => 'Lead',
];
