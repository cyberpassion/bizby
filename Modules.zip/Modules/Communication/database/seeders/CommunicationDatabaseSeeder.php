<?php

namespace Modules\Communication\Database\Seeders;

use Illuminate\Database\Seeder;

class CommunicationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
