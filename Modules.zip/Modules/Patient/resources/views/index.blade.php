<x-patient::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('patient.name') !!}</p>
</x-patient::layouts.master>
