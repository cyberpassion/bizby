<x-transport::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('transport.name') !!}</p>
</x-transport::layouts.master>
