<x-signup::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('signup.name') !!}</p>
</x-signup::layouts.master>
