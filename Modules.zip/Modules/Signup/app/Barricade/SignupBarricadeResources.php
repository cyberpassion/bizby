<?php

namespace Modules\Signup\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class SignupBarricadeResources
{
    public static function register(): void
    {
        
    }
}
