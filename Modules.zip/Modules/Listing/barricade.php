<?php
return [
    'path.listing.create' => [],
	'path.listing.read' => [],
	'path.listing.update' => [],
	'path.listing.delete' => [],
	'path.listing.list' => [],
	'path.listing.document' => [],
];