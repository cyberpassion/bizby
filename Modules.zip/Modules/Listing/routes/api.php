<?php

use Illuminate\Support\Facades\Route;
use Modules\Listing\Http\Controllers\ListingApiController;

Route::prefix('v1')
    ->middleware(['auth:sanctum', 'tenant'])
    ->group(function () {

        Route::apiResource(
            'listings',
            ListingApiController::class
        )->names('listings');
    });
