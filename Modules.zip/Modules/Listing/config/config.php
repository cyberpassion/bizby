<?php

return [
    'name' => 'Listing',
];
