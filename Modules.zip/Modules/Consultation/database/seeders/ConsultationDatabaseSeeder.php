<?php

namespace Modules\Consultation\Database\Seeders;

use Illuminate\Database\Seeder;

class ConsultationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
