<?php
return [
    'path.service.create' => [],
	'path.service.read' => [],
	'path.service.update' => [],
	'path.service.delete' => [],
	'path.service.list' => [],
	'path.service.document' => [],
];