<?php
return [
    'path.visitactivity.create' => [],
	'path.visitactivity.read' => [],
	'path.visitactivity.update' => [],
	'path.visitactivity.delete' => [],
	'path.visitactivity.list' => [],
	'path.visitactivity.document' => [],
];