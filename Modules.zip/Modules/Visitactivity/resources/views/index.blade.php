<x-visitactivity::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('visitactivity.name') !!}</p>
</x-visitactivity::layouts.master>
