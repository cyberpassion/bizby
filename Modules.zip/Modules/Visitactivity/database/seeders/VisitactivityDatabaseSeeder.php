<?php

namespace Modules\Visitactivity\Database\Seeders;

use Illuminate\Database\Seeder;

class VisitactivityDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
