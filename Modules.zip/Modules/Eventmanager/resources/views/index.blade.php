<x-eventmanager::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('eventmanager.name') !!}</p>
</x-eventmanager::layouts.master>
