<?php

namespace Modules\Eventmanager\Database\Seeders;

use Illuminate\Database\Seeder;

class EventmanagerDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
