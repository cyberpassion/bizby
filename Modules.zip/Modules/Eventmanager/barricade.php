<?php
return [
    'path.eventmanager.create' => [],
	'path.eventmanager.read' => [],
	'path.eventmanager.update' => [],
	'path.eventmanager.delete' => [],
	'path.eventmanager.list' => [],
	'path.eventmanager.document' => [],
];