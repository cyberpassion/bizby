<?php

return [
    'name' => 'Eventmanager',
];
