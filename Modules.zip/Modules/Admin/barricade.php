<?php
return [
    'path.admin.create' => [],
	'path.admin.read' => [],
	'path.admin.update' => [],
	'path.admin.delete' => [],
	'path.admin.list' => [],
	'path.admin.document' => [],
];