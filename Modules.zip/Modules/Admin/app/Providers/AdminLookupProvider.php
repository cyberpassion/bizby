<?php
namespace Modules\Admin\Providers;

class AdminLookupProvider
{
    public function getLookups()
    {
        return [];
    }

}
