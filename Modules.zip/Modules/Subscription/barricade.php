<?php
return [
    'path.subscription.create' => [],
	'path.subscription.read' => [],
	'path.subscription.update' => [],
	'path.subscription.delete' => [],
	'path.subscription.list' => [],
	'path.subscription.document' => [],
];