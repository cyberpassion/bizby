<x-subscription::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('subscription.name') !!}</p>
</x-subscription::layouts.master>
