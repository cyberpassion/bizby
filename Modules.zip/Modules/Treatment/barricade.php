<?php
return [
    'path.treatment.create' => [],
	'path.treatment.read' => [],
	'path.treatment.update' => [],
	'path.treatment.delete' => [],
	'path.treatment.list' => [],
	'path.treatment.document' => [],
];