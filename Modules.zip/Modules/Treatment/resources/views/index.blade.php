<x-treatment::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('treatment.name') !!}</p>
</x-treatment::layouts.master>
