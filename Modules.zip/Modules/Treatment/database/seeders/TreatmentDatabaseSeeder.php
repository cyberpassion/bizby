<?php

namespace Modules\Treatment\Database\Seeders;

use Illuminate\Database\Seeder;

class TreatmentDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
