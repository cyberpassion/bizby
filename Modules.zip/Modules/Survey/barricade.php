<?php
return [
    'path.survey.create' => [],
	'path.survey.read' => [],
	'path.survey.update' => [],
	'path.survey.delete' => [],
	'path.survey.list' => [],
	'path.survey.document' => [],
];