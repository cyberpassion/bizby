<?php
return [
    'path.examresult.create' => [],
	'path.examresult.read' => [],
	'path.examresult.update' => [],
	'path.examresult.delete' => [],
	'path.examresult.list' => [],
	'path.examresult.document' => [],
];