<?php
return [
    'path.announcement.create' => [],
	'path.announcement.read' => [],
	'path.announcement.update' => [],
	'path.announcement.delete' => [],
	'path.announcement.list' => [],
	'path.announcement.document' => [],
];