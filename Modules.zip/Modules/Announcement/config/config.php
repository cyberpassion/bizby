<?php

return [
    'name' => 'Announcement',
];
