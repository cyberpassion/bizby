<?php

return [
    'name' => 'Timetable',
];
