<x-test::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('test.name') !!}</p>
</x-test::layouts.master>
