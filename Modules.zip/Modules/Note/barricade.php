<?php
return [
    'path.note.create' => [],
	'path.note.read' => [],
	'path.note.update' => [],
	'path.note.delete' => [],
	'path.note.list' => [],
	'path.note.document' => [],
];