<x-note::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('note.name') !!}</p>
</x-note::layouts.master>
