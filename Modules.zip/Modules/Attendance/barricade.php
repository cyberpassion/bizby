<?php
return [
    'path.attendance.create' => [],
	'path.attendance.read' => [],
	'path.attendance.update' => [],
	'path.attendance.delete' => [],
	'path.attendance.list' => [],
	'path.attendance.document' => [],
];