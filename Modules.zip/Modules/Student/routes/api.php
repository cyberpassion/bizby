<?php

use Illuminate\Support\Facades\Route;
use Modules\Student\Http\Controllers\StudentApiController;

/*Route::middleware(['auth:sanctum'])->prefix('v1')->group(function () {
    Route::apiResource('students', StudentController::class)->names('student');
});*/

// Temporarily disable auth middleware
Route::prefix('v1')->group(function () {
    Route::apiResource('students', StudentApiController::class)->names('students');
});
