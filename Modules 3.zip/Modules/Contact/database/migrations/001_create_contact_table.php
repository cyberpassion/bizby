<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('contacts', function (Blueprint $table) {

            // Common SaaS fields (ID, client_id, status, audit, soft deletes, timestamps)
            $table->commonSaasFields();

            // Contact-specific fields
            $table->text('reference_name')->nullable();
            $table->bigInteger('reference_id')->nullable();
            
			// Patient/person info using macro
            $table->commonPersonFields();

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contacts');
    }
};