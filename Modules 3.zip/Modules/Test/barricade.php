<?php
return [
    'path.test.create' => [],
	'path.test.read' => [],
	'path.test.update' => [],
	'path.test.delete' => [],
	'path.test.list' => [],
	'path.test.document' => [],
];