<?php

namespace Modules\Test\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class TestBarricadeResources
{
    public static function register(): void
    {
        
    }
}
