<?php
return [
    'path.shared.create' => [],
	'path.shared.read' => [],
	'path.shared.update' => [],
	'path.shared.delete' => [],
	'path.shared.list' => [],
	'path.shared.document' => [],
];