<?php
return [
    'path.signup.create' => [],
	'path.signup.read' => [],
	'path.signup.update' => [],
	'path.signup.delete' => [],
	'path.signup.list' => [],
	'path.signup.document' => [],
];