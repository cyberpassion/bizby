<?php
return [
    'path.booking.create' => [],
	'path.booking.read' => [],
	'path.booking.update' => [],
	'path.booking.delete' => [],
	'path.booking.list' => [],
	'path.booking.document' => [],
];