<?php

namespace Modules\Booking\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class BookingBarricadeResources
{
    public static function register(): void
    {
        
    }
}
