<?php

namespace Modules\Eventmanager\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class EventmanagerBarricadeResources
{
    public static function register(): void
    {
        
    }
}
