<?php

namespace Modules\Shared\Database\Seeders\Terms;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class TermEmployeeTypeSeeder extends Seeder
{
    public function run(): void
    {
        $types = [
            'Permanent',
            'Contract',
            'Temporary',
            'Part Time',
            'Full Time',
            'Intern',
            'Trainee',
            'Consultant',
            'Freelancer',
            'Probation',
            'Apprentice',
            'Other',
        ];

        $data = [];

        foreach ($types as $index => $type) {
            $data[] = [
                'tenant_id'  => 1, // default / system
                'status'     => 1,
                'name'       => $type,
                'slug'       => Str::slug($type),
                'group'      => 'types',
                'module'     => 'employee',
                'sort_order' => $index + 1,
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }

        DB::table('terms')->upsert(
            $data,
            ['slug','tenant_id'],
            ['status','updated_at']
        );
    }
}
