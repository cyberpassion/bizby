<?php

namespace Modules\Shared\Models\OnlinePayments;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\Schema;

class OnlinePayment extends Model
{
    use HasFactory;

    protected $fillable = [];

    protected function dynamicFillable()
    {
        // Example dynamic load from DB table
        return Schema::getColumnListing($this->getTable());
    }

    public function getFillable()
    {
        return $this->dynamicFillable();
    }

	public function payable()
	{
    	return $this->morphTo();
	}

	public function payableRecord()
	{
    	return $this->hasOne(
	        PaymentPayable::class,
    	    'online_payment_id'
    	);
	}

}
