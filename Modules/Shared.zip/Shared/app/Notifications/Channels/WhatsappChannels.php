<?php

namespace Modules\Shared\Notifications\Channels;

class WhatsappChannel
{
    public static function send(string $to, array $template): void
    {
        // Meta WhatsApp API / Twilio WhatsApp
    }
}
