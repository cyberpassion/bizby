<?php

namespace Modules\Shared\Providers;

use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;
use Nwidart\Modules\Traits\PathNamespace;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

use Modules\Shared\Services\LookupRegistry;
use Modules\Shared\Services\BarricadeRegistry;

use Illuminate\Database\Eloquent\Relations\Relation;

use Modules\Shared\Services\OnlinePayments\RazorpayService;

use Modules\Shared\Barricade\SharedBarricadeResources;
use Modules\Shared\Services\OnlinePayments\PayableResolver;

class SharedServiceProvider extends ServiceProvider
{
    use PathNamespace;

    protected string $name = 'Shared';

    protected string $nameLower = 'shared';

    /**
     * Boot the application events.
     */
    public function boot(): void
    {
        $this->registerCommands();
        $this->registerCommandSchedules();
        $this->registerTranslations();
        $this->registerConfig();
        $this->registerViews();
        $this->loadMigrationsFrom(module_path($this->name, 'database/migrations'));

		// Lookups
		$this->loadPhpLookupsFromModules(); // Registers all lookup keys returning static values
		$this->loadDynamicLookupsFromProviders(); // Register all lookup keys wherein we fetch dynamic values

		// Barricades
	    SharedBarricadeResources::register(); // Shared module barricade resources
		$this->loadBarricadeRulesFromModules(); // Register barricade rules from all modules

		// Online Payment Services
		$this->app->singleton(RazorpayService::class, function () {
            return new RazorpayService();
        });
		$this->app->singleton(PayableResolver::class);

		// Loading Plesk API to create/delete databases for tenants
		$this->mergeConfigFrom( module_path('Shared', 'config/plesk.php'), 'plesk' );

		// Loading Email templates
		$this->loadViewsFrom( module_path('Shared', 'resources/views'), 'shared' );

		// Morph map registrations
		$this->registerMorphMaps();

		// Load global helpers
		$helpers = module_path('Shared', 'app/Helpers/helpers.php');
		if (file_exists($helpers)) {
    		require_once $helpers;
		}

		if ($this->app->runningInConsole()) {
	    	$this->app->booted(function () {
	    	    $this->registerAllModuleSchedules();
    	    	$this->loadAllModuleNotifications();
	    	});
		}

    }

	// Registers all lookup keys returning static values
	protected function loadPhpLookupsFromModules()
	{
    	$modulePath = base_path('Modules');

	    foreach (scandir($modulePath) as $module) {
    	    if ($module === '.' || $module === '..') continue;

        	$lookupFile = $modulePath . "/{$module}/lookups.php";

	        if (file_exists($lookupFile)) {
    	        $lookups = require $lookupFile;

	            foreach ($lookups as $key => $value) {
    	            LookupRegistry::register($key, $value);
        	    }
        	}
    	}
	}

	// Register all lookup keys wherein we fetch dynamic values
	protected function loadDynamicLookupsFromProviders()
	{
    	$modulePath = base_path('Modules');

	    foreach (scandir($modulePath) as $module) {
    	    if ($module === '.' || $module === '..') continue;

	        $providerClass = "Modules\\{$module}\\Providers\\{$module}LookupProvider";

	        if (!class_exists($providerClass)) {
    	        continue;
        	}

	        // ✅ ALWAYS use container
    	    try {
    	        $provider = app($providerClass);
    	    } catch (\Throwable $e) {
    	        logger()->error('Lookup provider failed', [
    	            'provider' => $providerClass,
    	            'error' => $e->getMessage()
    	        ]);
    	        continue;
    	    }

	        // 1️⃣ Normal lookup registration
    	    if (method_exists($provider, 'getLookups')) {
        	    foreach ($provider->getLookups() as $key => $value) {
            	    LookupRegistry::register($key, $value);
            	}
        	}

	        // 2️⃣ 🔥 FALLBACK registration (THIS WAS MISSING)
    	    if (method_exists($provider, 'register')) {
        	    $provider->register();
        	}
    	}
	}

	/**
	 * Register barricade rules from all modules
	 */
	protected function loadBarricadeRulesFromModules(): void
	{
	    $modulePath = base_path('Modules');

	    foreach (scandir($modulePath) as $module) {
    	    if ($module === '.' || $module === '..') continue;
			if (!is_dir($modulePath.'/'.$module)) {
				continue;
			}

	        $barricadeFile = $modulePath . "/{$module}/barricade.php";

	        if (!file_exists($barricadeFile)) {
    	        continue;
        	}

            $rules = require $barricadeFile;

	        if (!is_array($rules)) {
    	        continue;
        	}

	        foreach ($rules as $route => $definitions) {
    	        BarricadeRegistry::register($route, $definitions);
        	}
    	}
	}

    /**
     * Register the service provider.
     */
    public function register(): void
    {
        $this->app->register(EventServiceProvider::class);
        $this->app->register(RouteServiceProvider::class);
    }

    /**
     * Register commands in the format of Command::class
     */
    protected function registerCommands(): void
    {
        $this->commands([
			\Modules\Shared\Console\SyncScheduleJobs::class
		]);
    }

    /**
     * Register command Schedules.
     */
    protected function registerCommandSchedules(): void
    {
        // $this->app->booted(function () {
        //     $schedule = $this->app->make(Schedule::class);
        //     $schedule->command('inspire')->hourly();
        // });
    }

    /**
     * Register translations.
     */
    public function registerTranslations(): void
    {
        $langPath = resource_path('lang/modules/'.$this->nameLower);

        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->nameLower);
            $this->loadJsonTranslationsFrom($langPath);
        } else {
            $this->loadTranslationsFrom(module_path($this->name, 'lang'), $this->nameLower);
            $this->loadJsonTranslationsFrom(module_path($this->name, 'lang'));
        }
    }

    /**
     * Register config.
     */
    protected function registerConfig(): void
    {
        $configPath = module_path($this->name, config('modules.paths.generator.config.path'));

        if (is_dir($configPath)) {
            $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($configPath));

            foreach ($iterator as $file) {
                if ($file->isFile() && $file->getExtension() === 'php') {
                    $config = str_replace($configPath.DIRECTORY_SEPARATOR, '', $file->getPathname());
                    $config_key = str_replace([DIRECTORY_SEPARATOR, '.php'], ['.', ''], $config);
                    $segments = explode('.', $this->nameLower.'.'.$config_key);

                    // Remove duplicated adjacent segments
                    $normalized = [];
                    foreach ($segments as $segment) {
                        if (end($normalized) !== $segment) {
                            $normalized[] = $segment;
                        }
                    }

                    $key = ($config === 'config.php') ? $this->nameLower : implode('.', $normalized);

                    $this->publishes([$file->getPathname() => config_path($config)], 'config');
                    $this->merge_config_from($file->getPathname(), $key);
                }
            }
        }
    }

    /**
     * Merge config from the given path recursively.
     */
    protected function merge_config_from(string $path, string $key): void
    {
        $existing = config($key, []);
        try {
		    $module_config = require $path;
		} catch (\Throwable $e) {
		    logger()->error("Config load failed: {$path}", ['error' => $e->getMessage()]);
    		return;
		}

        config([$key => array_replace_recursive($existing, $module_config)]);
    }

    /**
     * Register views.
     */
    public function registerViews(): void
    {
        $viewPath = resource_path('views/modules/'.$this->nameLower);
        $sourcePath = module_path($this->name, 'resources/views');

        $this->publishes([$sourcePath => $viewPath], ['views', $this->nameLower.'-module-views']);

        $this->loadViewsFrom(array_merge($this->getPublishableViewPaths(), [$sourcePath]), $this->nameLower);

        Blade::componentNamespace(config('modules.namespace').'\\' . $this->name . '\\View\\Components', $this->nameLower);
    }

    /**
     * Get the services provided by the provider.
     */
    public function provides(): array
    {
        return [];
    }

    private function getPublishableViewPaths(): array
    {
        $paths = [];
        foreach (config('view.paths') as $path) {
            if (is_dir($path.'/modules/'.$this->nameLower)) {
                $paths[] = $path.'/modules/'.$this->nameLower;
            }
        }

        return $paths;
    }

	private function registerMorphMaps(): void
	{
		Relation::morphMap([
			/* ================= CORE ================= */
            'signup'       => \Modules\Signup\Models\Signup::class,
            'subscription' => \Modules\Subscription\Models\Subscription::class,
			'tenant'       => \Modules\Admin\Models\Tenants\TenantAccount::class,

            /* ================= PEOPLE ================= */
            'student'  => \Modules\Student\Models\Student::class,
            'employee' => \Modules\Employee\Models\Employee::class,
            'customer' => \Modules\Customer\Models\Customer::class,
            'patient'  => \Modules\Patient\Models\Patient::class,
            'vendor'   => \Modules\Vendor\Models\Vendor::class,
            'lead'     => \Modules\Lead\Models\Lead::class,

            /* ================= ACTIVITY ================= */
            'attendance'     => \Modules\Attendance\Models\Attendance::class,
            'survey'         => \Modules\Survey\Models\Survey::class,
            'checklist'      => \Modules\Checklist\Models\Checklist::class,
            //'note'           => \Modules\Notes\Models\Note::class,
            //'event'          => \Modules\Events\Models\Event::class,
            //'meeting'        => \Modules\Meetings\Models\Meeting::class,
            //'visit'          => \Modules\Visits\Models\Visit::class,
            //'task'           => \Modules\TaskPlanner\Models\Task::class,

            /* ================= COMMUNICATION ================= */
            'communication' => \Modules\Communication\Models\Communication::class,

            /* ================= BUSINESS / OPERATIONS ================= */
            'booking'     => \Modules\Booking\Models\Booking::class,
            'cashflow'    => \Modules\Cashflow\Models\Cashflow::class,
            'listing'     => \Modules\Listing\Models\Listing::class,
            'product'     => \Modules\Product\Models\Product::class,
            'saleservice' => \Modules\SaleService\Models\SaleService::class,
            'service'     => \Modules\Service\Models\Service::class,
            'transport'   => \Modules\Transport\Models\Transport::class,

            /* ================= EDUCATION ================= */
            'registration' => \Modules\Registration\Models\Registration::class,
            //'examresult'   => \Modules\ExamResult\Models\ExamResult::class,
            'timetable'    => \Modules\Timetable\Models\Timetable::class,
            'attendance' => \Modules\Attendance\Models\Attendance::class,
            'library'    => \Modules\Library\Models\Library::class,

            /* ================= HEALTHCARE ================= */
            'treatment'    => \Modules\Treatment\Models\Treatment::class,
            'consultation' => \Modules\Consultation\Models\Consultation::class,
            'patient'   	=> \Modules\Patient\Models\Patient::class,
		]);
	}

	private function registerAllModuleSchedules(): void
	{
    	if (!class_exists(\Modules\Shared\Services\Schedules\ScheduleJobRegistry::class)) {
        	logger()->warning('ScheduleJobRegistry missing, skipping schedule registration');
        	return;
	    }

	    foreach (\Nwidart\Modules\Facades\Module::allEnabled() as $module) {

	        $path = module_path($module->getName(), 'config/schedulable_jobs.php');

	        if (!file_exists($path)) {
    	        continue;
        	}

	        try {
    	        $jobs = require $path;
        	} catch (\Throwable $e) {
            	logger()->error('Failed loading schedulable jobs', [
                	'module' => $module->getName(),
	                'error' => $e->getMessage(),
    	        ]);
        	    continue;
        	}

	        foreach ($jobs as $key => $job) {

	            if (!isset($job['class']) || !class_exists($job['class'])) {
    	            logger()->error('Scheduled job class missing', [
        	            'module' => $module->getName(),
            	        'class' => $job['class'] ?? null,
                	]);
	                continue;
    	        }

	            \Modules\Shared\Services\Schedules\ScheduleJobRegistry::register(
	                key: strtolower($module->getName()) . '.' . $key,
    	            handler: fn () => dispatch(app($job['class'])),
        	        meta: array_merge($job, [
            	        'module' => strtolower($module->getName()),
                	])
            	);
        	}
    	}
	}

	private function loadAllModuleNotifications(): void
	{
    	foreach (\Nwidart\Modules\Facades\Module::allEnabled() as $module) {

	        $path = module_path($module->getName(), 'config/notifications.php');

    	    if (!file_exists($path)) {
        	    continue;
        	}

	        try {
    	        $config = require $path;
        	} catch (\Throwable $e) {
            	logger()->error('Failed loading notifications config', [
                	'module' => $module->getName(),
                	'error' => $e->getMessage(),
	            ]);
    	        continue;
        	}

	        if (!is_array($config)) {
    	        logger()->error('notifications.php must return array', [
        	        'module' => $module->getName(),
            	]);
            	continue;
	        }

	        config([
    	        'notifications' => array_replace_recursive(
        	        config('notifications', []),
            	    $config
	            )
    	    ]);
    	}
	}

}
