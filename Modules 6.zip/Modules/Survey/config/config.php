<?php

return [
    'name' => 'Survey',
];
