<?php

namespace Modules\Saleservice\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class SaleserviceBarricadeResources
{
    public static function register(): void
    {
        
    }
}
