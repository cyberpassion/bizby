<?php

return [
    'name' => 'Note',
];
