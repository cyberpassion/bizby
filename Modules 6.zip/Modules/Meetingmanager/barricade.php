<?php
return [
    'path.meetingmanager.create' => [],
	'path.meetingmanager.read' => [],
	'path.meetingmanager.update' => [],
	'path.meetingmanager.delete' => [],
	'path.meetingmanager.list' => [],
	'path.meetingmanager.document' => [],
];