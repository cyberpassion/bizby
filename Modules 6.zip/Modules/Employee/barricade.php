<?php
return [
    'path.employee.create' => [],
	'path.employee.read' => [],
	'path.employee.update' => [],
	'path.employee.delete' => [],
	'path.employee.list' => [],
	'path.employee.document' => [],
];