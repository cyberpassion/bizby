<?php

return [
    'name' => 'Patient',
];
