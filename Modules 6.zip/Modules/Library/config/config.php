<?php

return [
    'name' => 'Library',
];
