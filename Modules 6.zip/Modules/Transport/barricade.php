<?php
return [
    'path.transport.create' => [],
	'path.transport.read' => [],
	'path.transport.update' => [],
	'path.transport.delete' => [],
	'path.transport.list' => [],
	'path.transport.document' => [],
];