<?php
return [
    'path.registration.create' => [],
	'path.registration.read' => [],
	'path.registration.update' => [],
	'path.registration.delete' => [],
	'path.registration.list' => [],
	'path.registration.document' => [],
];