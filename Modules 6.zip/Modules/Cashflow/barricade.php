<?php
return [
    'path.cashflow.create' => [],
	'path.cashflow.read' => [],
	'path.cashflow.update' => [],
	'path.cashflow.delete' => [],
	'path.cashflow.list' => [],
	'path.cashflow.document' => [],
];