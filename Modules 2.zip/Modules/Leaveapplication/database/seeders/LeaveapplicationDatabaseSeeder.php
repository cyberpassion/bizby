<?php

namespace Modules\Leaveapplication\Database\Seeders;

use Illuminate\Database\Seeder;

class LeaveapplicationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
