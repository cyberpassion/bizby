<x-attendance::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('attendance.name') !!}</p>
</x-attendance::layouts.master>
