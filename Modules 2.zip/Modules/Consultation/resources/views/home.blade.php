<x-consultation::layouts.master>
    <h1>Hello World | Dashboard</h1>
</x-consultation::layouts.master>
