<?php

return [
    'name' => 'Examresult',
];
