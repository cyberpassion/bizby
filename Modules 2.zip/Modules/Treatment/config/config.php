<?php

return [
    'name' => 'Treatment',
];
