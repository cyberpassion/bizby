<?php

return [
    'name' => 'Signup',
];
