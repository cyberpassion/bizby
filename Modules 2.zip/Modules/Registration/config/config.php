<?php

return [
    'name' => 'Registration',
];
