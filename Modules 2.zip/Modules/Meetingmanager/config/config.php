<?php

return [
    'name' => 'Meetingmanager',
];
