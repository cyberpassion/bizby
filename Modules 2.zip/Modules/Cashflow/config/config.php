<?php

return [
    'name' => 'Cashflow',
];
