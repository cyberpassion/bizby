<?php

namespace Modules\Signup\Database\Seeders;

use Illuminate\Database\Seeder;

class SignupDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
