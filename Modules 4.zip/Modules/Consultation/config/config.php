<?php

return [
    'name' => 'Consultation',
];
