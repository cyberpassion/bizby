<?php
return [
    'path.checklist.create' => [],
	'path.checklist.read' => [],
	'path.checklist.update' => [],
	'path.checklist.delete' => [],
	'path.checklist.list' => [],
	'path.checklist.document' => [],
];