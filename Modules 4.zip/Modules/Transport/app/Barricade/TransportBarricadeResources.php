<?php

namespace Modules\Transport\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class TransportBarricadeResources
{
    public static function register(): void
    {
        
    }
}
