<?php

namespace Modules\Note\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class NoteBarricadeResources
{
    public static function register(): void
    {
        
    }
}
