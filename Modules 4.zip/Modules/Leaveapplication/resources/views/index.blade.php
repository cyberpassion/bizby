<x-leaveapplication::layouts.master>
    <h1>Hello World</h1>

    <p>Module: {!! config('leaveapplication.name') !!}</p>
</x-leaveapplication::layouts.master>
