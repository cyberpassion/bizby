<?php

namespace Modules\Attendance\Barricade;

use Modules\Shared\Services\BarricadeResourceRegistry;

class AttendanceBarricadeResources
{
    public static function register(): void
    {
        
    }
}
