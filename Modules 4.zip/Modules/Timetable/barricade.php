<?php
return [
    'path.timetable.create' => [],
	'path.timetable.read' => [],
	'path.timetable.update' => [],
	'path.timetable.delete' => [],
	'path.timetable.list' => [],
	'path.timetable.document' => [],
];