<?php
return [
    'path.saleservice.create' => [],
	'path.saleservice.read' => [],
	'path.saleservice.update' => [],
	'path.saleservice.delete' => [],
	'path.saleservice.list' => [],
	'path.saleservice.document' => [],
];